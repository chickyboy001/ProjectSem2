<?php

define('admin', 1); // quyền admin
define('client', 0);
define('VND', " VND");
define('link', "../../../ProjectSem2/");
define('link1', "../../../ProjectSem2/");
// define('link', '');
// define('link1', '../../');
?>